import * as ɵngcc0 from '@angular/core';
export declare class B2BServicesModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<B2BServicesModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<B2BServicesModule>;
}

//# sourceMappingURL=b2b-services.module.d.ts.map