/**
 * Представляет базовый класс сервиса кэша.
 */
import * as ɵngcc0 from '@angular/core';
export declare class CacheServiceBase {
    private data;
    /**
     * Добавляет элемент в кэш или заменяет его.
     * @param key Ключ.
     * @param value Значение.
     */
    putItem(key: string, value: any): void;
    /**
     * Возвращает элемент по ключу.
     * @param key Ключ.
     */
    getItem(key: string): any;
    /**
     * Возвращает элемент по ключу.
     * @param key Ключ.
     */
    get<T>(key: string): T;
    /**
     * Очищает содержимое кэша.
     */
    clear(): void;
    /**
     * Удаляет элемент по ключу.
     * @param key Ключ.
     */
    remove(key: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CacheServiceBase, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<CacheServiceBase>;
}

//# sourceMappingURL=cache-service-base.service.d.ts.map