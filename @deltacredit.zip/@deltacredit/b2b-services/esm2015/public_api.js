/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of dc-controls
 */
export { B2BServicesModule } from './lib/b2b-services.module';
export { CacheServiceBase } from './lib/cache-service-base/cache-service-base.service';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BkZWx0YWNyZWRpdC9iMmItc2VydmljZXMvIiwic291cmNlcyI6WyJwdWJsaWNfYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFHQSxrQ0FBYywyQkFBMkIsQ0FBQztBQUMxQyxpQ0FBYyxxREFBcUQsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgZGMtY29udHJvbHNcbiAqL1xuZXhwb3J0ICogZnJvbSAnLi9saWIvYjJiLXNlcnZpY2VzLm1vZHVsZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jYWNoZS1zZXJ2aWNlLWJhc2UvY2FjaGUtc2VydmljZS1iYXNlLnNlcnZpY2UnOyJdfQ==