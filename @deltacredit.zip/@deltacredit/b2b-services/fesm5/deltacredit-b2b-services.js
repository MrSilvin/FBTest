import { NgModule, Injectable } from '@angular/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import * as ɵngcc0 from '@angular/core';
var B2BServicesModule = /** @class */ (function () {
    function B2BServicesModule() {
    }
B2BServicesModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: B2BServicesModule });
B2BServicesModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function B2BServicesModule_Factory(t) { return new (t || B2BServicesModule)(); }, providers: [], imports: [[]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(B2BServicesModule, [{
        type: NgModule,
        args: [{
                imports: [],
                exports: [],
                providers: [],
                entryComponents: [],
                declarations: []
            }]
    }], function () { return []; }, null); })();
    return B2BServicesModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Представляет базовый класс сервиса кэша.
 */
var CacheServiceBase = /** @class */ (function () {
    function CacheServiceBase() {
        this.data = {};
    }
    /**
     * Добавляет элемент в кэш или заменяет его.
     * @param key Ключ.
     * @param value Значение.
     */
    /**
     * Добавляет элемент в кэш или заменяет его.
     * @param {?} key Ключ.
     * @param {?} value Значение.
     * @return {?}
     */
    CacheServiceBase.prototype.putItem = /**
     * Добавляет элемент в кэш или заменяет его.
     * @param {?} key Ключ.
     * @param {?} value Значение.
     * @return {?}
     */
    function (key, value) {
        this.data[key] = value;
    };
    /**
     * Возвращает элемент по ключу.
     * @param key Ключ.
     */
    /**
     * Возвращает элемент по ключу.
     * @param {?} key Ключ.
     * @return {?}
     */
    CacheServiceBase.prototype.getItem = /**
     * Возвращает элемент по ключу.
     * @param {?} key Ключ.
     * @return {?}
     */
    function (key) {
        return this.data[key];
    };
    /**
     * Возвращает элемент по ключу.
     * @param key Ключ.
     */
    /**
     * Возвращает элемент по ключу.
     * @template T
     * @param {?} key Ключ.
     * @return {?}
     */
    CacheServiceBase.prototype.get = /**
     * Возвращает элемент по ключу.
     * @template T
     * @param {?} key Ключ.
     * @return {?}
     */
    function (key) {
        return (/** @type {?} */ (this.getItem(key)));
    };
    /**
     * Очищает содержимое кэша.
     */
    /**
     * Очищает содержимое кэша.
     * @return {?}
     */
    CacheServiceBase.prototype.clear = /**
     * Очищает содержимое кэша.
     * @return {?}
     */
    function () {
        this.data = {};
    };
    /**
     * Удаляет элемент по ключу.
     * @param key Ключ.
     */
    /**
     * Удаляет элемент по ключу.
     * @param {?} key Ключ.
     * @return {?}
     */
    CacheServiceBase.prototype.remove = /**
     * Удаляет элемент по ключу.
     * @param {?} key Ключ.
     * @return {?}
     */
    function (key) {
        // delete в IE дает непредсказуемый результат.
        this.data[key] = null;
    };
CacheServiceBase.ɵfac = function CacheServiceBase_Factory(t) { return new (t || CacheServiceBase)(); };
CacheServiceBase.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: CacheServiceBase, factory: function (t) { return CacheServiceBase.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(CacheServiceBase, [{
        type: Injectable
    }], function () { return []; }, null); })();
    return CacheServiceBase;
}());
if (false) {
    /**
     * @type {?}
     * @private
     */
    CacheServiceBase.prototype.data;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { B2BServicesModule, CacheServiceBase };

//# sourceMappingURL=deltacredit-b2b-services.js.map