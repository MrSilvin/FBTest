import { Base } from './Base';
import { extend } from './extend';
var EntityProxyBase = /** @class */ (function () {
    function EntityProxyBase() {
        // files: File[] = []; // offline files attached to the entity
        this.$$Original = {};
    }
    EntityProxyBase.createFromObject = function (modelType, response) {
        if (response == null) {
            return null;
        }
        var convertedResponce = extend(new modelType(), response);
        convertedResponce.$$Original = response;
        return convertedResponce;
    };
    EntityProxyBase.createFromArray = function (modelType, data) {
        if (data == null) {
            return null;
        }
        return data.map(function (el) { return EntityProxyBase.createFromObject(modelType, el); });
    };
    /**
     * Возращает копию сущности. Копия имеет пустой id и является dirty.
     * @param modelType Тип сущности.
     * @param source Сущность для копирования.
     */
    EntityProxyBase.cloneEntity = function (modelType, source) {
        var newEntity = Object.assign(new modelType(), source);
        newEntity.$$Original = {};
        newEntity.id = void 0;
        return newEntity;
    };
    EntityProxyBase.prototype.toLookupItem = function (name) {
        if (name === void 0) { name = null; }
        return new Base.LookupItem(this.logicalname, this.id, name);
    };
    EntityProxyBase.equals = function (a, b) {
        if (a == null && b != null) {
            return false;
        }
        if (a != null && b == null) {
            return false;
        }
        if (a == null && b == null) {
            return true;
        }
        // Если пиклист или entityreference
        if (typeof b === 'object' && b.hasOwnProperty('value') && b.hasOwnProperty('name')) {
            return a.value === b.value;
        }
        return JSON.stringify(a) === JSON.stringify(b);
    };
    EntityProxyBase.prototype.validateQueriedColumns = function (attributeLogicalName) {
        if (this.requestedColumns != null && this.requestedColumns.indexOf(attributeLogicalName) < 0 && attributeLogicalName !== 'id') {
            throw new Error(this.logicalname + '.' + attributeLogicalName + ' не содержится в списке запрошенных полей');
        }
    };
    // атоматически вызывается при сериализации объекта в JSON
    EntityProxyBase.prototype.toJSON = function () {
        var result = { logicalname: this.logicalname };
        if (this.id != null) {
            result['id'] = this.id;
        }
        // конвертация полей localizable datetime в строку ISO формата
        for (var propertyName in this) {
            if (this.hasOwnProperty(propertyName) && propertyName.toString().startsWith('local_')) {
                this[propertyName.substr(6)] = this[propertyName];
            }
        }
        // сериализуем только изменившиеся поля
        for (var propertyName in this) {
            if (this.hasOwnProperty(propertyName) && propertyName.toString().charAt(0) === '_') {
                var origPropertyName = propertyName.substr(1);
                if (!EntityProxyBase.equals(this[propertyName], this.$$Original[origPropertyName])) {
                    result[origPropertyName] = this[propertyName];
                }
            }
        }
        return result;
    };
    EntityProxyBase.prototype.isFieldDirty = function (propertyName) {
        return !EntityProxyBase.equals(this['_' + propertyName], this.$$Original[propertyName]);
    };
    /**
     * Делает сущность не dirty.
     */
    EntityProxyBase.prototype.commitUpdates = function () {
        this.$$Original = extend(this.$$Original, this.toJSON());
    };
    /**
     * Фиксирует измененное свойство (исключает его из списка измененных свойств).
     * @param propertyName Имя свойства.
     * @param value Значение, которое необходимо зафиксировать в свойстве.
     */
    EntityProxyBase.prototype.commitPropertyValue = function (propertyName, value) {
        this[propertyName] = value;
        if (typeof value === 'object' && value !== null) {
            this.$$Original[propertyName] = Object.assign({}, this[propertyName]);
        }
        else {
            this.$$Original[propertyName] = this[propertyName];
        }
    };
    /**
     * Возвращает true, если в сущности есть измененные свойства.
     */
    EntityProxyBase.prototype.isDirty = function () {
        var changes = Object.keys(this.toJSON()).filter(function (x) { return x !== 'logicalname'; });
        if (changes.indexOf('id') !== -1 && changes.length > 1) {
            return true;
        }
        if (changes.indexOf('id') === -1 && changes.length > 0) {
            return true;
        }
        return false;
    };
    return EntityProxyBase;
}());
export { EntityProxyBase };
