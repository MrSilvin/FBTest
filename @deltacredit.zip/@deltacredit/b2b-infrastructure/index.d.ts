export * from './Base';
export * from './angular-indexeddb';
export * from './extend';
export * from './EntityProxyBase';
export declare enum DadataQueryType {
    fio = 0,
    address = 1,
    party = 2,
    bank = 3,
    email = 4,
    fms_unit_e4lezyvg8z = 5,
    job_title_e4lezeor4z = 6,
    jobPhone = 7,
    foreighAddress = 8
}
export declare enum FilterCompositionLogicalOperator {
    And = 0,
    Or = 1
}
export declare class FilterDescriptorBase {
}
export declare enum FilterOperator {
    IsLessThan = 0,
    IsLessThanOrEqualTo = 1,
    IsEqualTo = 2,
    IsNotEqualTo = 3,
    IsGreaterThanOrEqualTo = 4,
    IsGreaterThan = 5,
    StartsWith = 6,
    EndsWith = 7,
    Contains = 8,
    IsContainedIn = 9,
    DoesNotContain = 10
}
export declare class GetGridDataResponse<T> {
    data?: T[];
    total?: number;
    errors?: object;
    requestedColumns?: string[];
}
export declare enum ListSortDirection {
    Ascending = 0,
    Descending = 1
}
export declare class CompositeFilterDescriptor extends FilterDescriptorBase {
    logic?: FilterCompositionLogicalOperator;
    filters?: FilterDescriptorBase[];
}
export declare class DadataQueryRequest {
    query?: string;
    queryType?: DadataQueryType;
    parts?: string[];
}
export declare class FilterDescriptor extends FilterDescriptorBase {
    field?: string;
    operator?: FilterOperator;
    value?: object;
}
export declare class GetGridDataRequest {
    constructor(viewid: string, viewParams?: {
        [key: string]: string;
    }, page?: number, pageSize?: number, filter?: FilterDescriptorBase, sort?: SortDescriptor[]);
    viewid?: string;
    viewParams?: {
        [key: string]: string;
    };
    page?: number;
    pageSize?: number;
    sort?: SortDescriptor[];
    filter?: FilterDescriptorBase;
    group?: string;
    aggregate?: string;
}
export declare class SortDescriptor {
    member?: string;
    sortDirection?: ListSortDirection;
}
