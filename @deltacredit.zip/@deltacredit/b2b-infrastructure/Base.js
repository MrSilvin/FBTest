var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import * as moment from 'moment';
export var Base;
(function (Base) {
    var LookupItem = /** @class */ (function () {
        function LookupItem(logicalname, value, name) {
            this.logicalname = logicalname;
            this.value = value;
            this.name = name;
        }
        return LookupItem;
    }());
    Base.LookupItem = LookupItem;
    var SelectableLookupItem = /** @class */ (function (_super) {
        __extends(SelectableLookupItem, _super);
        function SelectableLookupItem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return SelectableLookupItem;
    }(LookupItem));
    Base.SelectableLookupItem = SelectableLookupItem;
    var PicklistItem = /** @class */ (function () {
        function PicklistItem(value, name) {
            this.value = value;
            this.name = name;
        }
        PicklistItem.equals = function (a, b) {
            return a != null && a.value === b;
        };
        return PicklistItem;
    }());
    Base.PicklistItem = PicklistItem;
    var Date = /** @class */ (function () {
        function Date(value, time) {
            this.value = value;
            this.time = time;
        }
        // isoDate: ISO-8601 formatted date returned from server
        Date.convertFromISO = function (isoDate) {
            //"2010-01-01T05:06:07"
            if (isoDate === "") {
                return new Base.Date();
            }
            if (isoDate == null) {
                return null;
            }
            var m = moment(isoDate, moment.ISO_8601);
            return new Base.Date(m.format('DD.MM.YYYY'), m.format('HH:mm'));
        };
        Date.convertToISO = function (localDate) {
            if (localDate == null) {
                return null;
            }
            if (localDate.value == null) {
                return "";
            }
            if (localDate.time == null) {
                var m_1 = moment(localDate.value, 'DD.MM.YYYYTHH:mm:ss');
                return m_1.utc().format();
            }
            var m = moment(localDate.value + 'T' + localDate.time, 'DD.MM.YYYYTHH:mm:ss');
            return m.utc().format();
        };
        return Date;
    }());
    Base.Date = Date;
})(Base || (Base = {}));
var LocalizableDate = /** @class */ (function (_super) {
    __extends(LocalizableDate, _super);
    function LocalizableDate() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return LocalizableDate;
}(Base.Date));
export { LocalizableDate };
