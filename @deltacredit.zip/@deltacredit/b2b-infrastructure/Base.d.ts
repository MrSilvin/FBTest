export declare module Base {
    class LookupItem {
        logicalname: string;
        value: string;
        name?: string;
        constructor(logicalname: string, value: string, name?: string);
    }
    class SelectableLookupItem extends LookupItem {
        isSelected?: boolean;
        isEnabled?: boolean;
    }
    class PicklistItem {
        value: number;
        name?: string;
        constructor(value: number, name?: string);
        static equals(a: PicklistItem, b: number): boolean;
    }
    class Date {
        value?: string;
        time?: string;
        constructor(value?: string, time?: string);
        static convertFromISO(isoDate: string): Base.Date;
        static convertToISO(localDate: Base.Date): string;
    }
}
export declare class LocalizableDate extends Base.Date {
}
