export function extend(target, source) {
    target = target || {};
    for (var prop in source) {
        if (source[prop] instanceof Array) {
            target[prop] = source[prop];
        }
        else if (typeof source[prop] === 'object' && source[prop] != null) {
            target[prop] = extend(target[prop], source[prop]);
        }
        else {
            target[prop] = source[prop];
        }
    }
    return target;
}
