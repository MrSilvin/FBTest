var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// this file is generated automatically. do not change it manually.
export * from './Base';
export * from './angular-indexeddb';
export * from './extend';
export * from './EntityProxyBase';
export var DadataQueryType;
(function (DadataQueryType) {
    DadataQueryType[DadataQueryType["fio"] = 0] = "fio";
    DadataQueryType[DadataQueryType["address"] = 1] = "address";
    DadataQueryType[DadataQueryType["party"] = 2] = "party";
    DadataQueryType[DadataQueryType["bank"] = 3] = "bank";
    DadataQueryType[DadataQueryType["email"] = 4] = "email";
    DadataQueryType[DadataQueryType["fms_unit_e4lezyvg8z"] = 5] = "fms_unit_e4lezyvg8z";
    DadataQueryType[DadataQueryType["job_title_e4lezeor4z"] = 6] = "job_title_e4lezeor4z";
    DadataQueryType[DadataQueryType["jobPhone"] = 7] = "jobPhone";
    DadataQueryType[DadataQueryType["foreighAddress"] = 8] = "foreighAddress";
})(DadataQueryType || (DadataQueryType = {}));
export var FilterCompositionLogicalOperator;
(function (FilterCompositionLogicalOperator) {
    FilterCompositionLogicalOperator[FilterCompositionLogicalOperator["And"] = 0] = "And";
    FilterCompositionLogicalOperator[FilterCompositionLogicalOperator["Or"] = 1] = "Or";
})(FilterCompositionLogicalOperator || (FilterCompositionLogicalOperator = {}));
var FilterDescriptorBase = /** @class */ (function () {
    function FilterDescriptorBase() {
    }
    return FilterDescriptorBase;
}());
export { FilterDescriptorBase };
export var FilterOperator;
(function (FilterOperator) {
    FilterOperator[FilterOperator["IsLessThan"] = 0] = "IsLessThan";
    FilterOperator[FilterOperator["IsLessThanOrEqualTo"] = 1] = "IsLessThanOrEqualTo";
    FilterOperator[FilterOperator["IsEqualTo"] = 2] = "IsEqualTo";
    FilterOperator[FilterOperator["IsNotEqualTo"] = 3] = "IsNotEqualTo";
    FilterOperator[FilterOperator["IsGreaterThanOrEqualTo"] = 4] = "IsGreaterThanOrEqualTo";
    FilterOperator[FilterOperator["IsGreaterThan"] = 5] = "IsGreaterThan";
    FilterOperator[FilterOperator["StartsWith"] = 6] = "StartsWith";
    FilterOperator[FilterOperator["EndsWith"] = 7] = "EndsWith";
    FilterOperator[FilterOperator["Contains"] = 8] = "Contains";
    FilterOperator[FilterOperator["IsContainedIn"] = 9] = "IsContainedIn";
    FilterOperator[FilterOperator["DoesNotContain"] = 10] = "DoesNotContain";
})(FilterOperator || (FilterOperator = {}));
var GetGridDataResponse = /** @class */ (function () {
    function GetGridDataResponse() {
    }
    return GetGridDataResponse;
}());
export { GetGridDataResponse };
export var ListSortDirection;
(function (ListSortDirection) {
    ListSortDirection[ListSortDirection["Ascending"] = 0] = "Ascending";
    ListSortDirection[ListSortDirection["Descending"] = 1] = "Descending";
})(ListSortDirection || (ListSortDirection = {}));
var CompositeFilterDescriptor = /** @class */ (function (_super) {
    __extends(CompositeFilterDescriptor, _super);
    function CompositeFilterDescriptor() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return CompositeFilterDescriptor;
}(FilterDescriptorBase));
export { CompositeFilterDescriptor };
var DadataQueryRequest = /** @class */ (function () {
    function DadataQueryRequest() {
    }
    return DadataQueryRequest;
}());
export { DadataQueryRequest };
var FilterDescriptor = /** @class */ (function (_super) {
    __extends(FilterDescriptor, _super);
    function FilterDescriptor() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FilterDescriptor;
}(FilterDescriptorBase));
export { FilterDescriptor };
var GetGridDataRequest = /** @class */ (function () {
    function GetGridDataRequest(viewid, viewParams, page, pageSize, filter, sort) {
        this.viewid = viewid;
        this.viewParams = viewParams;
        this.page = page;
        this.pageSize = pageSize;
        this.filter = filter;
        this.sort = sort;
    }
    return GetGridDataRequest;
}());
export { GetGridDataRequest };
var SortDescriptor = /** @class */ (function () {
    function SortDescriptor() {
    }
    return SortDescriptor;
}());
export { SortDescriptor };
