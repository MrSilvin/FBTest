import { Base } from './Base';
export declare abstract class EntityProxyBase {
    readonly logicalname: string;
    id: string;
    key: number;
    private $$Original;
    requestedColumns: string[];
    static createFromObject<T extends EntityProxyBase>(modelType: new () => T, response: T): T;
    static createFromArray<T extends EntityProxyBase>(modelType: new () => T, data: any[]): T[];
    /**
     * Возращает копию сущности. Копия имеет пустой id и является dirty.
     * @param modelType Тип сущности.
     * @param source Сущность для копирования.
     */
    static cloneEntity<T extends EntityProxyBase>(modelType: new () => T, source: T): T;
    toLookupItem(name?: string): Base.LookupItem;
    private static equals;
    validateQueriedColumns(attributeLogicalName: string): void;
    toJSON(): any;
    isFieldDirty(propertyName: string): boolean;
    /**
     * Делает сущность не dirty.
     */
    commitUpdates(): void;
    /**
     * Фиксирует измененное свойство (исключает его из списка измененных свойств).
     * @param propertyName Имя свойства.
     * @param value Значение, которое необходимо зафиксировать в свойстве.
     */
    commitPropertyValue(propertyName: string, value: any): void;
    /**
     * Возвращает true, если в сущности есть измененные свойства.
     */
    isDirty(): boolean;
}
