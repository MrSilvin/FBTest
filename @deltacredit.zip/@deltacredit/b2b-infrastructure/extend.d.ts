export declare function extend(target: any, source: any): any;
