import { Injectable, NgModule } from '@angular/core';
import { HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Subject, empty, throwError, of } from 'rxjs';
import { mergeMap, take, switchMap, retryWhen } from 'rxjs/operators';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @abstract
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common/http';
class IOAuth2Options {
}
if (false) {
    /** @type {?} */
    IOAuth2Options.prototype.clientId;
    /** @type {?} */
    IOAuth2Options.prototype.clientSecret;
    /** @type {?} */
    IOAuth2Options.prototype.redirectUri;
    /** @type {?} */
    IOAuth2Options.prototype.endpoints;
    /** @type {?} */
    IOAuth2Options.prototype.popUp;
    /** @type {?} */
    IOAuth2Options.prototype.localLoginUrl;
    /** @type {?} */
    IOAuth2Options.prototype.displayCall;
    /** @type {?} */
    IOAuth2Options.prototype.postLogoutRedirectUri;
    /** @type {?} */
    IOAuth2Options.prototype.cacheLocation;
    /** @type {?} */
    IOAuth2Options.prototype.anonymousEndpoints;
    /** @type {?} */
    IOAuth2Options.prototype.expireOffsetSeconds;
    /** @type {?} */
    IOAuth2Options.prototype.correlationId;
    /** @type {?} */
    IOAuth2Options.prototype.loginResource;
    /** @type {?} */
    IOAuth2Options.prototype.resource;
    /** @type {?} */
    IOAuth2Options.prototype.extraQueryParameter;
    /** @type {?} */
    IOAuth2Options.prototype.navigateToLoginRequestUrl;
    /** @type {?} */
    IOAuth2Options.prototype.logOutUri;
    /** @type {?} */
    IOAuth2Options.prototype.loggerEndpoint;
    /** @type {?} */
    IOAuth2Options.prototype.authorizeEndpoint;
    /** @type {?} */
    IOAuth2Options.prototype.tokenEndpoint;
    /** @type {?} */
    IOAuth2Options.prototype.scopes;
    /** @type {?} */
    IOAuth2Options.prototype.acr_values;
}
class OAuthCodeOptions {
    /**
     * @return {?}
     */
    static getLoginHint() { return window.localStorage.getItem('dcOAuthLoginHint'); }
    /**
     * @param {?} value
     * @return {?}
     */
    static setLoginHint(value) { window.localStorage.setItem('dcOAuthLoginHint', value); }
    /**
     * @param {?} options
     */
    constructor(options) {
        /** @type {?} */
        const obj = options.endpoints;
        /** @type {?} */
        const webApiUri = Object.keys(obj)[0];
        this.authorizeEndpoint = options.authorizeEndpoint;
        this.tokenEndpoint = (options.tokenEndpoint == null) ? (webApiUri + 'OAuth/TokenHandler') : options.tokenEndpoint;
        this.loggerEndpoint = options.loggerEndpoint;
        this.clientId = options.clientId;
        this.clientSecret = options.clientSecret;
        this.redirectUri = options.redirectUri;
        this.localStoragePrefix = obj[webApiUri];
        this.resourceUri = obj[webApiUri];
        this.extraQueryParameter = options.extraQueryParameter;
        this.scopes = options.scopes;
        this.acr_values = options.acr_values;
    }
}
if (false) {
    /** @type {?} */
    OAuthCodeOptions.prototype.authorizeEndpoint;
    /** @type {?} */
    OAuthCodeOptions.prototype.tokenEndpoint;
    /** @type {?} */
    OAuthCodeOptions.prototype.loggerEndpoint;
    /** @type {?} */
    OAuthCodeOptions.prototype.clientId;
    /** @type {?} */
    OAuthCodeOptions.prototype.clientSecret;
    /** @type {?} */
    OAuthCodeOptions.prototype.redirectUri;
    /** @type {?} */
    OAuthCodeOptions.prototype.localStoragePrefix;
    /** @type {?} */
    OAuthCodeOptions.prototype.resourceUri;
    /** @type {?} */
    OAuthCodeOptions.prototype.scopes;
    /** @type {?} */
    OAuthCodeOptions.prototype.acr_values;
    /** @type {?} */
    OAuthCodeOptions.prototype.extraQueryParameter;
}
/**
 * @record
 */
function ITokenResponce() { }
if (false) {
    /** @type {?} */
    ITokenResponce.prototype.access_token;
    /** @type {?} */
    ITokenResponce.prototype.refresh_token;
    /** @type {?} */
    ITokenResponce.prototype.expires_in;
    /** @type {?} */
    ITokenResponce.prototype.error;
}
class OAuthHandler {
    /**
     * @param {?} options
     */
    constructor(options) {
        this.options = new OAuthCodeOptions(options);
        this.accessTokenParamName = this.options.localStoragePrefix + '$1';
        this.refreshTokenParamName = this.options.localStoragePrefix + '$2';
        this.accessTokenExpiryParamName = this.options.localStoragePrefix + '$3';
    }
    /**
     * @protected
     * @return {?}
     */
    get accessToken() { return window.localStorage.getItem(this.accessTokenParamName); }
    /**
     * @protected
     * @param {?} value
     * @return {?}
     */
    set accessToken(value) { window.localStorage.setItem(this.accessTokenParamName, value); }
    /**
     * @protected
     * @return {?}
     */
    get refreshToken() { return window.localStorage.getItem(this.refreshTokenParamName); }
    /**
     * @protected
     * @param {?} value
     * @return {?}
     */
    set refreshToken(value) { window.localStorage.setItem(this.refreshTokenParamName, value); }
    /**
     * @protected
     * @return {?}
     */
    get accessTokenExpiry() { return parseInt(window.localStorage.getItem(this.accessTokenExpiryParamName), 10); }
    /**
     * @protected
     * @param {?} value
     * @return {?}
     */
    set accessTokenExpiry(value) { window.localStorage.setItem(this.accessTokenExpiryParamName, value.toString()); }
    /**
     * @protected
     * @return {?}
     */
    get state() { return window.sessionStorage.getItem(this.options.localStoragePrefix + 'state'); }
    /**
     * @protected
     * @param {?} value
     * @return {?}
     */
    set state(value) { window.sessionStorage.setItem(this.options.localStoragePrefix + 'state', value); }
    /**
     * @protected
     * @return {?}
     */
    get callbackRedirectUri() { return window.localStorage.getItem(this.options.localStoragePrefix + 'CallbackRedirectUri'); }
    /**
     * @protected
     * @param {?} value
     * @return {?}
     */
    set callbackRedirectUri(value) { window.localStorage.setItem(this.options.localStoragePrefix + 'CallbackRedirectUri', value); }
    /**
     * @protected
     * @return {?}
     */
    removeAccessToken() { window.localStorage.removeItem(this.accessTokenParamName); }
    /**
     * @protected
     * @return {?}
     */
    removeRefreshToken() { window.localStorage.removeItem(this.refreshTokenParamName); }
    /**
     * @protected
     * @return {?}
     */
    removeAccessTokenExpiry() { window.localStorage.removeItem(this.accessTokenExpiryParamName); }
    /**
     * @protected
     * @return {?}
     */
    removeState() { window.sessionStorage.removeItem(this.options.localStoragePrefix + 'state'); }
    /**
     * @protected
     * @return {?}
     */
    clearStorage() {
        this.removeAccessToken();
        this.removeRefreshToken();
        this.removeAccessTokenExpiry();
    }
    /**
     * @protected
     * @param {?} data
     * @return {?}
     */
    param(data) {
        /** @type {?} */
        let result = '';
        for (const key in data) {
            if (data.hasOwnProperty(key) && data[key] != '' && data[key] != null) {
                if (result) {
                    result += '&';
                }
                result += key + '=' + encodeURIComponent(data[key]);
            }
        }
        return result;
    }
    /**
     * @protected
     * @param {?} type
     * @param {?} data
     * @return {?}
     */
    error(type, data) {
        if (this.options.error) {
            this.options.error(type, data);
        }
    }
    /**
     * @protected
     * @param {?} data
     * @return {?}
     */
    newAccessToken(data) {
        this.accessToken = data.access_token || '';
        if (data.refresh_token) {
            this.refreshToken = data.refresh_token;
        }
        if (data.expires_in) {
            this.accessTokenExpiry = Date.now() + data.expires_in * 1000;
        }
        else if (this.accessTokenExpiry) {
            this.removeAccessTokenExpiry();
        }
    }
}
if (false) {
    /**
     * @type {?}
     * @private
     */
    OAuthHandler.prototype.accessTokenParamName;
    /**
     * @type {?}
     * @private
     */
    OAuthHandler.prototype.refreshTokenParamName;
    /**
     * @type {?}
     * @private
     */
    OAuthHandler.prototype.accessTokenExpiryParamName;
    /**
     * @type {?}
     * @protected
     */
    OAuthHandler.prototype.options;
}
class CallbackHandler extends OAuthHandler {
    /**
     * @param {?} options
     */
    constructor(options) {
        super(options);
    }
    /**
     * @private
     * @param {?} search
     * @param {?} name
     * @return {?}
     */
    getUrlParameter(search, name) {
        /** @type {?} */
        const part = search.match(RegExp('[?|&]' + name + '=(.*?)(&|$)'));
        if (part) {
            return decodeURIComponent(part[1]);
        }
        else {
            return null;
        }
    }
    /**
     * @param {?} search
     * @return {?}
     */
    authorizationResponse(search) {
        /** @type {?} */
        const error = this.getUrlParameter(search, 'error');
        if (error != null) {
            /** @type {?} */
            const error_description = this.getUrlParameter(search, 'error_description');
            alert(error + ':' + error_description);
            throw Error(error);
        }
        /** @type {?} */
        const code = this.getUrlParameter(search, 'code');
        if (code == null) {
            return false;
        }
        /** @type {?} */
        const state = this.getUrlParameter(search, 'state');
        /** @type {?} */
        const sessionState = this.state;
        if (state !== sessionState || state == null) {
            alert('Authorization session id mistmatch');
            throw Error('Authorization session id mistmatch');
        }
        /** @type {?} */
        const req = new XMLHttpRequest();
        req.open('POST', this.options.tokenEndpoint, true);
        req.setRequestHeader('Accept', 'application/json');
        req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        req.onerror = (/**
         * @param {?} ev
         * @return {?}
         */
        (ev) => this.error('XMLHttpRequest error', ev));
        req.onload = (/**
         * @return {?}
         */
        () => {
            if (req.readyState === req.DONE) {
                /** @type {?} */
                let data = {};
                try {
                    data = JSON.parse(req.responseText);
                    this.log('onload', data);
                }
                catch (ex) {
                    this.error('authorize', ex);
                    alert('Ошибка авторизации.');
                    this.removeState();
                    this.newAccessToken(data);
                    ((/** @type {?} */ (data))).responseParseException = req.responseText;
                    this.log('catch', data);
                    setTimeout((/**
                     * @return {?}
                     */
                    () => { window.location.replace(this.callbackRedirectUri); }), 10);
                    return;
                }
                if (data.error) {
                    this.error('authorize', data);
                }
                else {
                    this.removeState();
                    this.newAccessToken(data);
                    this.log('reopen', data);
                    setTimeout((/**
                     * @return {?}
                     */
                    () => { window.location.replace(this.callbackRedirectUri); }), 10);
                }
            }
        });
        req.send(this.param({
            client_id: this.options.clientId,
            client_secret: this.options.clientSecret,
            grant_type: 'authorization_code',
            code: code,
            scope: (this.options.scopes || []).join(' '),
            redirect_uri: this.options.redirectUri
        }));
        return true;
    }
    /**
     * @param {?} specflag
     * @param {?} data
     * @return {?}
     */
    log(specflag, data) {
        if (this.options.loggerEndpoint) {
            try {
                /** @type {?} */
                const req = new XMLHttpRequest();
                req.open('POST', this.options.loggerEndpoint, true);
                req.setRequestHeader('Encoding', 'UTF8');
                req.setRequestHeader('Content-Type', 'text/plain');
                req.onerror = (/**
                 * @param {?} ev
                 * @return {?}
                 */
                (ev) => this.error('XMLHttpRequest error', ev));
                ((/** @type {?} */ (data))).specflag = specflag;
                req.send(JSON.stringify({ message: data }));
            }
            catch (_a) { }
        }
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class OAuth2Interceptor extends OAuthHandler {
    /**
     * @param {?} options
     * @param {?} http
     */
    constructor(options, http) {
        super(options);
        this.http = http;
        this.tokenPending = false;
        this.authorizePending = false;
        this.newTokenSubj = new Subject();
    }
    /**
     * @param {?} value
     * @param {?} scheme
     * @return {?}
     */
    static _parseAuthenticateHeader(value, scheme) {
        if (!value) {
            return null;
        }
        /** @type {?} */
        const patterns = [
            ['token', /^([!#$%&'*+\-.^_`|~\w\/]+(?:={1,2}$)?)/],
            ['token', /^"(([^"\\]|\\\\|\\")+)"/],
            [null, /^\s+/],
            ['equals', /^(=)/],
            ['comma', /^(,)/],
        ];
        // Tokenize
        /** @type {?} */
        const tokens = [];
        while (value.length) {
            /** @type {?} */
            let i = 0;
            for (i = 0; i < patterns.length; i++) {
                /** @type {?} */
                const name = patterns[i][0];
                /** @type {?} */
                const pattern = (/** @type {?} */ (patterns[i][1]));
                /** @type {?} */
                const match = pattern.exec(value);
                if (match) {
                    if (name) {
                        tokens.push([name, match[1]]);
                    }
                    value = value.substr(match[0].length);
                    break;
                }
            }
            if (i === patterns.length) {
                // Ran out of patterns
                return null;
            }
        }
        // Join name-value pairs
        for (let i = 0; i < tokens.length - 2; i++) {
            if (tokens[i][0] === 'token' &&
                tokens[i + 1][0] === 'equals' &&
                tokens[i + 2][0] === 'token') {
                /** @type {?} */
                const pair = {};
                pair[tokens[i][1]] = tokens[i + 2][1];
                tokens.splice(i, 3, ['pair', pair]);
            }
        }
        // Construct challenges
        /** @type {?} */
        const groupedChallenges = [];
        while (tokens.length) {
            /** @type {?} */
            let i = 1;
            if (tokens.length === 1) { }
            else if (tokens[1][0] === 'comma') { }
            else if (tokens[1][0] === 'token') {
                i = 2;
            }
            else {
                while (i < tokens.length && tokens[i][0] === 'pair') {
                    i += 2;
                }
                i -= 1;
            }
            groupedChallenges.push([tokens[0][1], tokens.slice(1, i)]);
            tokens.splice(0, i + 1);
        }
        /** @type {?} */
        const challenges = {};
        for (const challenge of groupedChallenges) {
            /** @type {?} */
            const args = [];
            /** @type {?} */
            let kwargs = {};
            /** @type {?} */
            const name2 = challenge[0];
            /** @type {?} */
            const tokens2 = challenge[1];
            for (const token of tokens2) {
                if (token[0] === 'token') {
                    args.push(token[1]);
                }
                else if (token[0] === 'pair') {
                    kwargs = Object.assign(kwargs, token[1]);
                }
            }
            if (!challenges.hasOwnProperty(name2)) {
                challenges[name2] = args.length ? args[0] : kwargs;
            }
            else {
                challenges[name2] = Object.assign(challenges[name2], args.length ? args[0] : kwargs);
            }
        }
        if (scheme) {
            return challenges[scheme];
        }
        else {
            return challenges;
        }
    }
    /**
     * @private
     * @return {?}
     */
    _authorize() {
        if (this.authorizePending) {
            return;
        }
        this.authorizePending = true;
        this.removeRefreshToken();
        /** @type {?} */
        const state = (Math.random() * 1000000).toString();
        this.state = state;
        /** @type {?} */
        let authorizeUrl = this.options.authorizeEndpoint + '?' +
            this.param({
                response_type: 'code',
                resource: this.options.resourceUri,
                client_id: this.options.clientId,
                redirect_uri: this.options.redirectUri,
                scope: (this.options.scopes || []).join(' '),
                acr_values: (this.options.acr_values || []).join(' '),
                state
            });
        if (this.options.extraQueryParameter) {
            authorizeUrl += '&' + this.options.extraQueryParameter;
        }
        this.callbackRedirectUri = window.location.toString();
        setTimeout((/**
         * @return {?}
         */
        () => { window.location.assign(authorizeUrl); }), 10);
    }
    /**
     * @private
     * @return {?}
     */
    refreshAccessToken() {
        if (!this.tokenPending) {
            this.tokenPending = true;
            this.http.post(this.options.tokenEndpoint, this.param({
                client_id: this.options.clientId,
                client_secret: this.options.clientSecret,
                grant_type: 'refresh_token',
                refresh_token: this.refreshToken
            }), {
                headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' }
            }).subscribe((/**
             * @param {?} data
             * @return {?}
             */
            data => {
                if (!data || !data.access_token || data.error) {
                    this.error('refresh', data);
                    this._authorize();
                }
                else {
                    this.newAccessToken(data);
                    this.tokenPending = false;
                    this.newTokenSubj.next(data.access_token);
                }
            }), (/**
             * @param {?} err
             * @return {?}
             */
            (err) => this._authorize()));
        }
        return this.newTokenSubj;
    }
    /**
     * @private
     * @param {?} req
     * @return {?}
     */
    makeRequest(req) {
        /** @type {?} */
        const accessToken = this.accessToken;
        /** @type {?} */
        let newheaders = req.headers;
        if (accessToken) {
            newheaders = newheaders.set('Authorization', 'Bearer ' + accessToken);
        }
        return req.clone({ headers: newheaders });
    }
    /**
     * @private
     * @param {?} error
     * @return {?}
     */
    handle401(error) {
        /** @type {?} */
        const bearerParams = OAuth2Interceptor._parseAuthenticateHeader(error.headers.get('WWW-Authenticate'), 'Bearer');
        if (bearerParams && bearerParams.error === 'invalid_token' && this.refreshToken) {
            return this.refreshAccessToken();
        }
        else {
            this._authorize();
            return empty();
        }
    }
    /**
     * @private
     * @param {?} errors
     * @return {?}
     */
    handle401RetryStrategy(errors) {
        return errors.pipe(mergeMap((/**
         * @param {?} error
         * @param {?} i
         * @return {?}
         */
        (error, i) => {
            if (error.status !== 401) {
                return throwError(error);
            }
            return this.handle401(error);
        })));
    }
    /**
     * @param {?} req
     * @param {?} next
     * @return {?}
     */
    intercept(req, next) {
        if (req.url.startsWith(this.options.tokenEndpoint)) {
            return next.handle(req);
        }
        return this.ensureAccessTokenLifetime(null, 10000)
            .pipe(take(1), switchMap((/**
         * @return {?}
         */
        () => next.handle(this.makeRequest(req)))), retryWhen((/**
         * @param {?} errors
         * @return {?}
         */
        errors => this.handle401RetryStrategy(errors))));
    }
    /**
     * @param {?} url
     * @param {?=} millis
     * @return {?}
     */
    ensureAccessTokenLifetime(url, millis = 10000) {
        /** @type {?} */
        const expiresAt = this.accessTokenExpiry;
        if (expiresAt && Date.now() + millis > expiresAt) {
            return this.refreshAccessToken();
        }
        return of(this.accessToken);
    }
}
OAuth2Interceptor.ɵfac = function OAuth2Interceptor_Factory(t) { return new (t || OAuth2Interceptor)(ɵngcc0.ɵɵinject(IOAuth2Options), ɵngcc0.ɵɵinject(ɵngcc1.HttpClient)); };
OAuth2Interceptor.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: OAuth2Interceptor, factory: OAuth2Interceptor.ɵfac });
/** @nocollapse */
OAuth2Interceptor.ctorParameters = () => [
    { type: IOAuth2Options },
    { type: HttpClient }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(OAuth2Interceptor, [{
        type: Injectable
    }], function () { return [{ type: IOAuth2Options }, { type: ɵngcc1.HttpClient }]; }, null); })();
if (false) {
    /**
     * @type {?}
     * @private
     */
    OAuth2Interceptor.prototype.tokenPending;
    /**
     * @type {?}
     * @private
     */
    OAuth2Interceptor.prototype.authorizePending;
    /**
     * @type {?}
     * @private
     */
    OAuth2Interceptor.prototype.newTokenSubj;
    /**
     * @type {?}
     * @private
     */
    OAuth2Interceptor.prototype.http;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class DcOauthModule {
}
DcOauthModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: DcOauthModule });
DcOauthModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function DcOauthModule_Factory(t) { return new (t || DcOauthModule)(); }, providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: OAuth2Interceptor,
            multi: true
        },
        OAuth2Interceptor
    ], imports: [[]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(DcOauthModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [],
                exports: [],
                providers: [
                    {
                        provide: HTTP_INTERCEPTORS,
                        useClass: OAuth2Interceptor,
                        multi: true
                    },
                    OAuth2Interceptor
                ]
            }]
    }], null, null); })();

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { DcOauthModule, IOAuth2Options, OAuth2Interceptor, OAuthHandler as ɵa };

//# sourceMappingURL=deltacredit-dc-oauth.js.map