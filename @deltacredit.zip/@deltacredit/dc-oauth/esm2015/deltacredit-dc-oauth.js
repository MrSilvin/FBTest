/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { IOAuth2Options, OAuth2Interceptor, DcOauthModule } from './public_api';
export { OAuthHandler as ɵa } from './lib/callback';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVsdGFjcmVkaXQtZGMtb2F1dGguanMiLCJzb3VyY2VzIjpbIkBkZWx0YWNyZWRpdC9kYy1vYXV0aC9kZWx0YWNyZWRpdC1kYy1vYXV0aC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBSUEsaUVBQWMsY0FBYyxDQUFDOztBQUFBLEFBQUEsQUFBQSxBQUFBLEFBRUEsQUFBQSxBQUFBLEFBQUEsQUFBQSxBQUFBLEFBQUEsQUFBQSxBQUFBLEFBQUEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEdlbmVyYXRlZCBidW5kbGUgaW5kZXguIERvIG5vdCBlZGl0LlxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vcHVibGljX2FwaSc7XG5cbmV4cG9ydCB7T0F1dGhIYW5kbGVyIGFzIMm1YX0gZnJvbSAnLi9saWIvY2FsbGJhY2snOyJdfQ==