/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of dc-oauth
 */
export { OAuth2Interceptor } from './lib/oauth2interceptor';
export { DcOauthModule } from './lib/dc-oauth.module';
export { IOAuth2Options } from './lib/callback';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BkZWx0YWNyZWRpdC9kYy1vYXV0aC8iLCJzb3VyY2VzIjpbInB1YmxpY19hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUlBLGtDQUFjLHlCQUF5QixDQUFDO0FBQ3hDLDhCQUFjLHVCQUF1QixDQUFDO0FBQ3RDLE9BQVEsRUFBRSxjQUFjLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgZGMtb2F1dGhcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2xpYi9vYXV0aDJpbnRlcmNlcHRvcic7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9kYy1vYXV0aC5tb2R1bGUnO1xuZXhwb3J0ICB7IElPQXV0aDJPcHRpb25zIH0gZnJvbSAnLi9saWIvY2FsbGJhY2snO1xuIl19