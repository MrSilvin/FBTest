/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { OAuthHandler as ɵa } from './lib/callback';

//# sourceMappingURL=deltacredit-dc-oauth.d.ts.map