import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { OAuthHandler, IOAuth2Options } from './callback';
import * as ɵngcc0 from '@angular/core';
export declare class OAuth2Interceptor extends OAuthHandler implements HttpInterceptor {
    private http;
    private tokenPending;
    private authorizePending;
    private newTokenSubj;
    constructor(options: IOAuth2Options, http: HttpClient);
    static _parseAuthenticateHeader(value: any, scheme: any): any;
    private _authorize;
    private refreshAccessToken;
    private makeRequest;
    private handle401;
    private handle401RetryStrategy;
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    ensureAccessTokenLifetime(url: string, millis?: number): Observable<string>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<OAuth2Interceptor, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<OAuth2Interceptor>;
}

//# sourceMappingURL=oauth2interceptor.d.ts.map