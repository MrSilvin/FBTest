export declare abstract class IOAuth2Options {
    clientId: string;
    clientSecret?: string;
    redirectUri?: string;
    endpoints?: any;
    popUp?: boolean;
    localLoginUrl?: string;
    displayCall?: (urlNavigate: string) => any;
    postLogoutRedirectUri?: string;
    cacheLocation?: string;
    anonymousEndpoints?: string[];
    expireOffsetSeconds?: number;
    correlationId?: string;
    loginResource?: string;
    resource?: string;
    extraQueryParameter?: string;
    navigateToLoginRequestUrl?: boolean;
    logOutUri?: string;
    loggerEndpoint?: string;
    authorizeEndpoint: string;
    tokenEndpoint?: string;
    scopes?: Array<string>;
    acr_values?: Array<string>;
}
export declare class OAuthCodeOptions {
    authorizeEndpoint: string;
    tokenEndpoint: string;
    loggerEndpoint: string;
    clientId: string;
    clientSecret: string;
    redirectUri?: string;
    localStoragePrefix: string;
    resourceUri: string;
    scopes?: Array<string>;
    acr_values?: Array<string>;
    extraQueryParameter?: string;
    static getLoginHint(): string;
    static setLoginHint(value: string): void;
    error?(type: any, data: any): void;
    constructor(options: IOAuth2Options);
}
export interface ITokenResponce {
    access_token: string;
    refresh_token: string;
    expires_in: number;
    error: string;
}
export declare class OAuthHandler {
    private readonly accessTokenParamName;
    private readonly refreshTokenParamName;
    private readonly accessTokenExpiryParamName;
    protected readonly options: OAuthCodeOptions;
    constructor(options: IOAuth2Options);
    protected accessToken: string;
    protected refreshToken: string;
    protected accessTokenExpiry: number;
    protected state: string;
    protected callbackRedirectUri: string;
    protected removeAccessToken(): void;
    protected removeRefreshToken(): void;
    protected removeAccessTokenExpiry(): void;
    protected removeState(): void;
    protected clearStorage(): void;
    protected param(data: any): string;
    protected error(type: any, data: any): void;
    protected newAccessToken(data: ITokenResponce): void;
}
export declare class CallbackHandler extends OAuthHandler {
    constructor(options: IOAuth2Options);
    private getUrlParameter;
    authorizationResponse(search: any): boolean;
    log(specflag: string, data: object): void;
}
