import * as ɵngcc0 from '@angular/core';
export declare class DcOauthModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<DcOauthModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<DcOauthModule>;
}

//# sourceMappingURL=dc-oauth.module.d.ts.map