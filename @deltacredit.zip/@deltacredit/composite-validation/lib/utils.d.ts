import { WrappedValue, ValueValidationError } from './types';
import { StringLiteralEnum } from './string-literal.enum';
export declare class Utils {
    private static readonly defaultError;
    private static _literalMatches;
    private static readonly literalMatches;
    private static initErrors;
    static options: {
        passValues: boolean;
    };
    /**
     * Возвращает текст ошибки по ключу.
     * @param key Ключ, представленный перечислением StringLiteralEnum.
     */
    static getLiteralValue(key: StringLiteralEnum): string;
    /**
     * Возвращает текст ошибки по ключу.
     * @param key Ключ, представленный строкой.
     */
    static getLiteralValue(key: string): string;
    /**
     * Sets literal value globally.
     * @param key Key as a string.
     * @param key Value text.
     */
    static setLiteralValue(key: string, value: string): void;
    /**
     * Sets literal value globally.
     * @param key Key as a StringLiteralEnum constant.
     * @param key Value text.
     */
    static setLiteralValue(key: StringLiteralEnum, value: string): void;
    static getError(key: StringLiteralEnum): string;
    /**
     * Returns error value.
     * @param key Key as a StringLiteralEnum constant.
     */
    static getError(key: string): string;
    /**
     * Заменяет токены ({0}, {1}, и т.д.) в строке и возвращает измененную строку.
     * @param message Строка с токенами.
     * @param args Значения для замены.
     */
    static evaluateMessage(message: string, args: any[]): string;
    /**
     * Returns instance of error object.
     * @param error Error string or object.
     * @param isRequired Value is required.
     * @param args Values for substitution using token replacer.
     */
    static getErrorObject(error: string | ValueValidationError, isRequired?: boolean, args?: any[]): ValueValidationError;
    /**
     * Returns instance of value wrapper.
     * @param value Inner value.
     * @param isRequired Value is required.
     */
    static getWrappedValue<T>(value: T, isRequired?: boolean): WrappedValue<T>;
    /**
     * Если аргумент WrappedValue, возвращает внутьреннее значение.
     * Иначе возвращает аргумент.
     * @param value Value wrapper or JS basic type value.
     */
    static tryGetValue<T>(obj: WrappedValue<T> | T): T;
}
//# sourceMappingURL=utils.d.ts.map