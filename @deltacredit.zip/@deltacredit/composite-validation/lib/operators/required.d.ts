import { ValueValidationError } from '../types';
/**
 * Value is required (should be defined).
 * @param val Verified value.
 */
export declare function required(val: any): any;
/**
 * If condition returns true value is required (should be defined).
 * @param val Verified value.
 * @param condition Condition represented by function (returns true/false).
 */
export declare function required(val: any, condition: () => boolean): any;
/**
 * If condition returns true value is required (should be defined).
 * @param val Verified value.
 * @param condition Condition represented by function (returns true/false).
 * @param error Error text or object.
 */
export declare function required(val: any, condition: () => boolean, error: string | ValueValidationError): any;
//# sourceMappingURL=required.d.ts.map