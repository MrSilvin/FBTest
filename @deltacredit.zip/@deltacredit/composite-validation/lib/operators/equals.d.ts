import { ValueValidationError, OperatorOptions } from '../types';
/**
 * Value should be equal to target.
 * @param val Verified value.
 * @param target Target value.
 */
export declare function equals(val: any, target: any): any;
/**
 * If condition returns true Value should be equal to target/
 * @param val Verified value.
 * @param target Target value.
 * @param condition Condition represented by function (returns true/false).
 */
export declare function equals(val: any, target: any, condition: () => boolean): any;
/**
 * If condition returns true Value should be equal to target/
 * @param val Verified value.
 * @param target Target value.
 * @param condition Condition represented by function (returns true/false).
 * @param error Error text or object.
 */
export declare function equals(val: any, target: any, condition: () => boolean, error: string | ValueValidationError): any;
/**
 * If condition returns true Value should be equal to target/
 * @param val Verified value.
 * @param target Target value.
 * @param condition Condition represented by function (returns true/false).
 * @param error Error text or object.
 * @param options Operator options.
 */
export declare function equals(val: any, target: any, condition: () => boolean, error: string | ValueValidationError, options: OperatorOptions): any;
//# sourceMappingURL=equals.d.ts.map