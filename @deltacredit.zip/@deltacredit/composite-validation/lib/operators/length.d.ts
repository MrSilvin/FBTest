/**
 * Длина строки не должна быть в указанном диапазоне.
 * @param val Проверяемое значение.
 * @param min Минимальная длина.
 */
export declare function length(val: any, min: number): any;
/**
 * Длина строки должна быть в указанном диапазоне.
 * @param val Проверяемое значение.
 * @param min Минимальная длина.
 * @param max Максимальная длина.
 */
export declare function length(val: any, min: number, max: number): any;
/**
 * Если выполняется заданное условие, длина строки должна быть в указанном диапазоне.
 * @param val Проверяемое значение.
 * @param min Минимальная длина.
 * @param max Максимальная длина.
 * @param condition Условие, представленное функцией, возвращающей логическое значение.
 */
export declare function length(val: any, min: number, max: number, condition: () => boolean): any;
//# sourceMappingURL=length.d.ts.map