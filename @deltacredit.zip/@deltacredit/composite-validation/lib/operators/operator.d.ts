import { ValueValidationError } from '../types';
/**
 * Value must perform the specified conditions.
 * @param val Verified value.
 * @param isValidFunc Custom validation function (returns true/false).
 */
export declare function operator(val: any, isValidFunc: () => boolean): any;
/**
 * If condition returns true value must perform the specified conditions.
 * @param val Verified value.
 * @param isValidFunc Validity conditions represented by custom validation function (returns true/false).
 * @param condition Condition represented by function (returns true/false).
 */
export declare function operator(val: any, isValidFunc: () => boolean, condition: () => boolean): any;
/**
 * If condition returns true value must perform the specified conditions.
 * @param val Verified value.
 * @param isValidFunc Validity conditions represented custom validation function (returns true/false).
 * @param condition Condition represented by function (returns true/false).
 * @param error Error text or object.
 */
export declare function operator(val: any, isValidFunc: () => boolean, condition: () => boolean, error: string | ValueValidationError): any;
//# sourceMappingURL=operator.d.ts.map