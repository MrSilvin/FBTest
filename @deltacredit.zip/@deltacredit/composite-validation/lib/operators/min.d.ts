/**
 * Значение не должно быть меньше указанного минимума.
 * @param val Проверяемое значение.
 */
export declare function min(val: any, minValue: number): any;
/**
 * Если выполняется заданное условие, значение не должно быть меньше указанного минимума.
 * @param val Проверяемое значение.
 * @param minValue Минимум.
 * @param condition Условие, представленное функцией, возвращающей логическое значение.
 */
export declare function min(val: any, minValue: number, condition: () => boolean): any;
/**
 * Если выполняется заданное условие, значение не должно быть меньше указанного минимума.
 * @param val Проверяемое значение.
 * @param val Минимум.
 * @param condition Условие, представленное функцией, возвращающей логическое значение.
 * @param error Текст или объект ошибки.
 */
export declare function min(val: any, minValue: number, condition: () => boolean, error: string): any;
//# sourceMappingURL=min.d.ts.map