import { ValueValidationError } from '../types';
/**
 * Строка должна соответствовать регулярному выражению.
 * @param val Проверяемое значение.
 * @param regex Регулярное выражение.
 */
export declare function isMatch(val: any, regex: RegExp): any;
/**
 * Если выполняется заданное условия, строка должна соответствовать регулярному выражению.
 * @param val Проверяемое значение.
 * @param regex Регулярное выражение.
 * @param condition Условие, представленное функцией, возвращающей логическое значение.
 */
export declare function isMatch(val: any, regex: RegExp, condition: () => boolean): any;
/**
 * Если выполняется заданное условия, строка должна соответствовать регулярному выражению.
 * @param val Проверяемое значение.
 * @param regex Регулярное выражение.
 * @param condition Условие, представленное функцией, возвращающей логическое значение.
 * @param error Текст или объект ошибки.
 */
export declare function isMatch(val: any, regex: RegExp, condition: () => boolean, error: string | ValueValidationError): any;
//# sourceMappingURL=is-match.d.ts.map