/**
 * Значение не должно быть больше указанного минимума.
 * @param val Проверяемое значение.
 */
export declare function max(val: any, maxValue: number): any;
/**
 * Если выполняется заданное условие, значение не должно быть больше указанного минимума.
 * @param val Проверяемое значение.
 * @param maxValue Максимум.
 * @param condition Условие, представленное функцией, возвращающей логическое значение.
 */
export declare function max(val: any, maxValue: number, condition: () => boolean): any;
/**
 * Если выполняется заданное условие, значение не должно быть больше указанного минимума.
 * @param val Проверяемое значение.
 * @param maxValue Максимум.
 * @param condition Условие, представленное функцией, возвращающей логическое значение.
 * @param error Текст или объект ошибки.
 */
export declare function max(val: any, maxValue: number, condition: () => boolean, error: string): any;
//# sourceMappingURL=max.d.ts.map