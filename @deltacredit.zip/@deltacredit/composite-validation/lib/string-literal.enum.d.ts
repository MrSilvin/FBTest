export declare enum StringLiteralEnum {
    required = 0,
    equals = 1,
    invalid = 2,
    notAString = 3,
    length = 4,
    lengthRange = 5,
    lengthMin = 6,
    lengthMax = 7,
    invalidRange = 8,
    lessThanZero = 9,
    min = 10,
    max = 11,
    notANumber = 12,
    invalidCondition = 13,
    invalidValidationMap = 14,
    prefixForGeneratedNames = 15
}
//# sourceMappingURL=string-literal.enum.d.ts.map