/**
 * Validation function.
 */
export declare type ValidationFunction<T> = (data: T) => WrappedValue<T> | ValueValidationError;
/**
 * Mixed validation function.
 */
export declare type MixedValidationFunction<T> = ValidationFunction<T> | Array<ValidationFunction<T>> | VMap<T>;
/**
 * Validation map for data model.
 */
export declare type VMap<T> = {
    [TKey in keyof Partial<T>]: MixedValidationFunction<T[TKey]>;
};
/**
 * Обернутое значение.
 */
export declare class WrappedValue<T> {
    value: T;
    isRequired: boolean;
    /**
     * Creates instance of wrapper.
     * @param value Inner wrapper value.
     * @param isRequired Value is required.
     */
    constructor(value: T, isRequired?: boolean);
}
/**
 * Data model's value validation error.
 */
export declare class ValueValidationError {
    error: string;
    isRequired: boolean;
    value: any;
    /**
     * Creates instance of error's object.
     * @param error Error message.
     * @param isRequired Value is required.
     */
    constructor(error: string, isRequired?: boolean, value?: any);
}
export interface OperatorOptions {
    evaluatedErrorValueTransformer?: (val: any) => string;
}
//# sourceMappingURL=types.d.ts.map