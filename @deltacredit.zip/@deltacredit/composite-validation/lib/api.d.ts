import { VMap, ValidationFunction } from './types';
/**
 * Sets validity conditions for data model's value.
 * @param vFunctions Conditions represented by one or more validation functions (operators).
 */
export declare function Conditions<T>(...vFunctions: ValidationFunction<T>[]): ValidationFunction<T>;
declare type Unpacked<T> = T extends (infer U)[] ? U : T;
/**
 * Applies conditions or validation map for each item of array.
 * @param f Validity conditions or validation map.
 * Example:
 * Each(targetArr => Conditions(elementOfArray => someCondition(elementOfArray)))
 * Each(targetArr => ValidationMap( elementOfArray => ({ ... }) ))
 * Array<T>
 * T[]
 */
export declare function Each<T>(e: (arr: T) => ValidationFunction<Unpacked<T>>): ValidationFunction<T>;
/**
 * Creates validation map for data model.
 * @param m Function returned validation map definition.
 * Example:
 * ValidationMap( target => ({ someProp: Conditions(...) }) )
 */
export declare function ValidationMap<T>(m: (data: T) => VMap<T>): ValidationFunction<T>;
export {};
//# sourceMappingURL=api.d.ts.map