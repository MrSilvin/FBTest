# composite-validation
Composite validation API for JS data models. Based on [this](https://github.com/uNmAnNeR/travajs "travajs") project idea.
